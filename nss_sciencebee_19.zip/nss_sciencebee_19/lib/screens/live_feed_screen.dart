import 'package:flutter/material.dart';

class LiveFeedScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('The Live Feed'),
    );
  }
}
